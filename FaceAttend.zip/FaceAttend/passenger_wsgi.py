import os
import sys
from app_new import app as application

# Add the project directory to the sys.path
sys.path.insert(0, os.path.dirname(__file__))